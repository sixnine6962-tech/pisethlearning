self.addEventListener("push", (event) => {
  let message = {
    title: "PisethLearning",
    body: "ដល់ម៉ោងរៀនហើយ! Time for a little English.",
  };
  try {
    if (event.data) message = { ...message, ...event.data.json() };
  } catch {
    /* Use the friendly default. */
  }
  event.waitUntil(
    self.registration.showNotification(String(message.title).slice(0, 100), {
      body: String(message.body).slice(0, 240),
      icon: "/icon.svg",
      tag: "piseth-reminder",
    }),
  );
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((clients) => {
        const app = clients.find(
          (c) => new URL(c.url).origin === self.location.origin,
        );
        return app ? app.focus() : self.clients.openWindow("/");
      }),
  );
});
