# PisethLearning

A mobile-first English–Khmer classroom for Cambodian beginners. MadeBy: TryPiseth.LLC.

## Run the application

Use Node.js 20.9 or later, PostgreSQL, and a private `DATABASE_URL` environment variable. Install dependencies with `npm install`, create tables with `npx drizzle-kit push`, then run `npm run dev`. Deploy the production build on a Node.js/Next.js host. See [`HOSTING.md`](./HOSTING.md). Next.js serves `src/app/page.tsx` as the homepage; this full-stack application does not have a root `index.html`.

## Create an account and sign in

- The home classroom works in guest mode. Select **Profile → Sign in / Create account** to open the family welcome screen.
- **Create account:** enter the learner’s name and age, choose a family Parent PIN and daily limit, then create a family account with any valid Gmail, Outlook, or other email address and a password.
- Passwords require at least eight characters and a repeated confirmation. **Sign-in is immediate. No OTP, demo code, email verification, SMTP provider, or inbox check is used.**
- Sign in any time with the same normalized email and password. A successful login restores progress from PostgreSQL.
- Passwords are never saved in plain text. The server uses Node’s memory-hard scrypt (`N=32768`, `r=8`, `p=1`) with a fresh 16-byte random salt and stores only the derived hash.
- Login and account-creation requests have a PostgreSQL-backed limit of 12 attempts per 15 minutes for each pseudonymous email/IP pair. For another layer, set a private random `AUTH_RATE_LIMIT_SECRET` in the hosting environment.
- Sessions use a random 256-bit HttpOnly, SameSite=Strict cookie; HTTPS deployments also set Secure. Session-token hashes—not raw tokens—are stored in PostgreSQL. Sessions expire after 30 days and are revoked when signed out.
- Families can change their password in **Profile → Change password** after entering the Parent PIN and current password. Email password-reset links intentionally do not exist because email verification is disabled. If the current password is lost, it cannot be recovered via email.
- Learner progress remains in `localStorage` and is backed up to PostgreSQL after family sign-in. A child’s PIN is saved as a separate salted PBKDF2 digest, never as the plain four-digit PIN.

## Curriculum

`src/lib/lessonsData.ts` contains 5 units, 25 progressive lessons, 126 vocabulary entries, and **276 activities**. It covers all 26 letters. Each lesson introduces five useful words and practices picture choice, listening, matching, sentence building, pronunciation, and bilingual stories. The conversation club adds longer dialogues, listening, and comprehension.

All English instructions and question prompts have a speaker button; translations use locally hosted Kantumruy Pro. Artwork and fonts are bundled.

## Family safety and progress

The default Parent PIN for a fresh guest profile is **0000**. Set a private PIN when creating an account. Change it later in Parents’ corner. A time limit can only be changed after verifying the PIN; a settings panel automatically re-locks after two minutes.

Presets are 5, 10, 15, 20, and 30 minutes, with custom limits of 1–240 minutes. Bedtime uses the local device clock. Active sessions and unfinished lesson bookmarks survive refresh. At bedtime or when time expires, a bell sounds and lessons lock until the next day or until the parent approves extra time. A website cannot prevent users from closing a browser, changing device time, or editing their own local browser data; use device-level controls for strict enforcement.

The league shows anonymous aliases—not email addresses or children’s names. Weekly scores reset on Monday. Audio uses the Web Speech API with an offline, microphone-free speaking fallback.

## Validation

Run `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, `npm run lint`, `npm run build`, and `npx playwright test` (after installing Chromium with `npx playwright install chromium`).
