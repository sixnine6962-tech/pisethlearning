"use client";
import { LearningProvider, useLearning } from "@/lib/learning";
import { bi, exerciseCount, units } from "@/lib/lessonsData";
import { dayKey, formatTime, streak } from "@/lib/model";
import {
  ArrowRight,
  Check,
  ChevronRight,
  Clock3,
  Heart,
  LockKeyhole,
  ShoppingBag,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { FlameArt, GemArt, Tiger, UnitArt } from "./Art";
import { AuthFlow, PasswordChange } from "./AuthFlow";
import {
  LeaguePage,
  ProfilePage,
  QuestsPage,
  Shop,
  SpeakPage,
} from "./Destinations";
import { LearnPage, UnitDetails } from "./Learn";
import { ParentControls, PinGate } from "./ParentControls";
import {
  BottomNav,
  EnglishFlag,
  Sidebar,
  Topbar,
  type Info,
  type Tab,
} from "./Shell";
import { RestScreen, StudySession } from "./StudySession";
import { BiText, Modal, ProgressBar } from "./UI";
type Panel =
  | Info
  | "pin"
  | "parent"
  | "shop"
  | "auth"
  | "password"
  | "unit"
  | null;
type Gate = "settings" | "exit" | "auth" | "logout" | "password";
function Application() {
  const { data, seconds, update, start, end, toast, message } = useLearning();
  const [tab, setTab] = useState<Tab>("learn"),
    [panel, setPanel] = useState<Panel>(null),
    [unit, setUnit] = useState(1),
    [gate, setGate] = useState<Gate>("settings");
  const close = useCallback(() => setPanel(null), []);
  const parent = useCallback(() => {
    setGate("settings");
    setPanel("pin");
  }, []);
  function navigate(t: Tab) {
    setTab(t);
    setPanel(null);
    window.history.replaceState(
      null,
      "",
      t === "learn" ? window.location.pathname : `#${t}`,
    );
    window.scrollTo({ top: 0 });
  }
  useEffect(() => {
    const read = () => {
      const v = location.hash.slice(1);
      if (["learn", "speak", "league", "quests", "profile"].includes(v))
        setTab(v as Tab);
    };
    read();
    window.addEventListener("hashchange", read);
    return () => window.removeEventListener("hashchange", read);
  }, []);
  function openUnit(id: number) {
    setUnit(id);
    setPanel("unit");
  }
  function requirePin(action: Gate) {
    setGate(action);
    setPanel("pin");
  }
  function openAuth() {
    if (data.pinHash || data.onboarded) requirePin("auth");
    else setPanel("auth");
  }
  function openPasswordChange() {
    requirePin("password");
  }
  async function unlocked() {
    if (gate === "settings") {
      setPanel("parent");
      return;
    }
    if (gate === "auth") {
      setPanel("auth");
      return;
    }
    if (gate === "password") {
      setPanel("password");
      return;
    }
    if (gate === "exit") {
      end();
      setPanel(null);
      toast("Session ended. Your progress is saved. · បានរក្សាទុកការសិក្សា");
      return;
    }
    try {
      const r = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "logout" }),
      });
      if (!r.ok) throw new Error();
      update((s) => ({ ...s, account: "guest", email: "" }));
      toast("Signed out. Learning progress stays on this device.");
    } catch {
      toast("Could not sign out. Please try again.");
    }
    setPanel(null);
  }
  return (
    <>
      {data.rest ? (
        <RestScreen onParent={parent} />
      ) : data.session ? (
        <StudySession onExit={() => requirePin("exit")} />
      ) : (
        <div className="app-shell">
          <Sidebar tab={tab} onTab={navigate} onParent={parent} />
          <div className="app-workspace">
            <div className="mobile-brand">
              <Tiger size={27} />
              <b>PisethLearning</b>
              <span>ENGLISH FOR KIDS</span>
            </div>
            <Topbar onInfo={setPanel} onProfile={() => navigate("profile")} />
            <main className="page-content" id="main-content">
              {tab === "learn" ? (
                <LearnPage
                  onUnit={openUnit}
                  onQuests={() => navigate("quests")}
                />
              ) : tab === "speak" ? (
                <SpeakPage />
              ) : tab === "league" ? (
                <LeaguePage />
              ) : tab === "quests" ? (
                <QuestsPage />
              ) : (
                <ProfilePage
                  onParent={parent}
                  onAuth={openAuth}
                  onShop={() => setPanel("shop")}
                  onPassword={openPasswordChange}
                  onLogout={() => requirePin("logout")}
                />
              )}
            </main>
          </div>
          <BottomNav tab={tab} onTab={navigate} />
        </div>
      )}
      {panel && (
        <Modal
          key={panel}
          title={
            panel === "pin"
              ? "Parent PIN"
              : panel === "parent"
                ? "Parental controls"
                : panel === "auth"
                  ? "Family sign in"
                  : panel === "password"
                    ? "Change family password"
                    : panel === "unit"
                      ? units[unit - 1].title.en
                      : panel
          }
          onClose={close}
          wide={panel === "parent" || panel === "course"}
        >
          {panel === "pin" ? (
            <PinGate
              purpose={
                gate === "exit"
                  ? "Enter your PIN to end this learning session."
                  : gate === "logout"
                    ? "Enter your PIN to sign out of this account."
                    : gate === "auth"
                      ? "Enter your PIN to manage the family account."
                      : gate === "password"
                        ? "Enter your Parent PIN to change the family password."
                        : "Enter your four-digit PIN to manage family settings."
              }
              onSuccess={unlocked}
            />
          ) : panel === "parent" ? (
            <ParentControls onDone={close} onRelock={parent} />
          ) : panel === "auth" ? (
            <AuthFlow onDone={close} />
          ) : panel === "password" ? (
            <PasswordChange onDone={close} />
          ) : panel === "shop" ? (
            <Shop />
          ) : panel === "unit" ? (
            <UnitDetails
              unit={units[unit - 1]}
              onStart={(id) => {
                close();
                start(id);
              }}
            />
          ) : panel === "course" ? (
            <>
              <div className="course-modal-flag">
                <EnglishFlag />
              </div>
              <span className="eyebrow">YOUR ACTIVE COURSE</span>
              <BiText
                text={bi(
                  "English for beginners",
                  "ភាសាអង់គ្លេសសម្រាប់អ្នកចាប់ផ្តើម",
                )}
                as="h2"
                className="modal-heading"
              />
              <p className="auth-copy">
                5 units · 25 lessons · {exerciseCount} activities
              </p>
              <div className="course-outline">
                {units.map((u) => (
                  <button key={u.id} onClick={() => openUnit(u.id)}>
                    <span style={{ background: u.tint }}>
                      <UnitArt unit={u.id} size={42} />
                    </span>
                    <div>
                      <small>UNIT {u.id}</small>
                      <b>{u.title.en}</b>
                      <p className="km">{u.title.km}</p>
                    </div>
                    <ChevronRight size={16} />
                  </button>
                ))}
              </div>
            </>
          ) : panel === "time" ? (
            <>
              <div className="modal-icon green">
                <Clock3 size={29} />
              </div>
              <BiText
                as="h2"
                text={bi("Your learning time", "ពេលរៀនរបស់អ្នក")}
                className="modal-heading"
              />
              <div className="big-timer">
                {formatTime(seconds)}
                <small>remaining today · នៅសល់ថ្ងៃនេះ</small>
              </div>
              <ProgressBar
                value={seconds}
                max={(data.limit + data.bonus) * 60}
              />
              <div className="info-facts">
                <span>
                  Daily limit <b>{data.limit} minutes</b>
                </span>
                <span>
                  Bedtime lock <b>{data.bedtimeOn ? data.bedtime : "Off"}</b>
                </span>
              </div>
              <BiText
                text={bi(
                  "Only your grown-up can change learning time.",
                  "មានតែអាណាព្យាបាលប៉ុណ្ណោះដែលអាចកែប្រែម៉ោងរៀន។",
                )}
                className="form-description"
              />
              <button className="secondary full" onClick={parent}>
                <LockKeyhole size={16} />
                Parental controls
              </button>
            </>
          ) : panel === "gems" ? (
            <>
              <div className="modal-icon blue">
                <GemArt size={37} />
              </div>
              <BiText
                as="h2"
                text={bi("Your gem collection", "បណ្ដុំត្បូងរបស់អ្នក")}
                className="modal-heading"
              />
              <strong className="big-stat">
                {data.gems} <small>gems</small>
              </strong>
              <BiText
                text={bi(
                  "Collect gems by finishing lessons and daily goals.",
                  "ប្រមូលត្បូងដោយបញ្ចប់មេរៀន និងគោលដៅប្រចាំថ្ងៃ។",
                )}
                className="form-description"
              />
              <div className="info-facts">
                <span>
                  Welcome gift<b>50 gems</b>
                </span>
                <span>
                  New lesson completed<b>+5 gems</b>
                </span>
                <span>
                  Daily goals reward<b>+10 gems</b>
                </span>
              </div>
              <button className="primary full" onClick={() => setPanel("shop")}>
                <ShoppingBag size={17} />
                Visit the explorer shop
              </button>
            </>
          ) : panel === "hearts" ? (
            <>
              <div className="modal-icon coral">
                <Heart size={30} fill="currentColor" />
              </div>
              <BiText
                text={bi("Your learning hearts", "បេះដូងរៀនរបស់អ្នក")}
                as="h2"
                className="modal-heading"
              />
              <div className="hearts-display">
                {[0, 1, 2, 3, 4].map((i) => (
                  <Heart
                    key={i}
                    size={36}
                    fill={i < data.hearts ? "#eb9299" : "#e4e7eb"}
                    stroke={i < data.hearts ? "#e67f88" : "#d7dce1"}
                  />
                ))}
              </div>
              <BiText
                text={bi(
                  "Start each day with five hearts. Mistakes help you learn!",
                  "ចាប់ផ្តើមរាល់ថ្ងៃជាមួយបេះដូងប្រាំ។ កំហុសជួយឱ្យអ្នកចេះ!",
                )}
                className="form-description"
              />
              <p className="muted-caption">
                Hearts refresh tomorrow. You can always keep practicing, even
                with no hearts left.
              </p>
              <button
                className="secondary full"
                onClick={() => setPanel("shop")}
              >
                Explore the shop
                <ArrowRight size={15} />
              </button>
            </>
          ) : (
            <>
              <div className="modal-icon gold">
                <FlameArt size={37} />
              </div>
              <BiText
                text={bi("Your learning streak", "ថ្ងៃរៀនជាប់គ្នារបស់អ្នក")}
                as="h2"
                className="modal-heading"
              />
              <strong className="big-stat">
                {streak(data)}{" "}
                <small>{streak(data) === 1 ? "day" : "days"}</small>
              </strong>
              <div className="streak-week">
                {Array.from({ length: 7 }, (_, i) => {
                  const d = new Date();
                  d.setDate(d.getDate() - (6 - i));
                  return (
                    <div key={i}>
                      <small>
                        {d.toLocaleDateString("en-US", { weekday: "narrow" })}
                      </small>
                      <span
                        className={
                          data.dates.includes(dayKey(d))
                            ? "done"
                            : i === 6
                              ? "today"
                              : ""
                        }
                      >
                        {data.dates.includes(dayKey(d)) ? (
                          <Check size={15} />
                        ) : (
                          d.getDate()
                        )}
                      </span>
                    </div>
                  );
                })}
              </div>
              <BiText
                text={bi(
                  "Finish a lesson or a conversation to grow your streak.",
                  "បញ្ចប់មេរៀន ឬការសន្ទនា ដើម្បីបង្កើនថ្ងៃរៀនជាប់គ្នា។",
                )}
                className="form-description"
              />
              <button className="primary full" onClick={close}>
                Got it · យល់ហើយ
              </button>
            </>
          )}
        </Modal>
      )}
      {message && (
        <div className="toast" role="status">
          <Check size={16} />
          {message}
        </div>
      )}
    </>
  );
}
export default function PisethApp() {
  return (
    <LearningProvider>
      <Application />
    </LearningProvider>
  );
}
