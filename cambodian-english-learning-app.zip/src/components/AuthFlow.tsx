"use client";
import { useState, type FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  Check,
  KeyRound,
  LockKeyhole,
  Mail,
  ShieldCheck,
} from "lucide-react";
import { useLearning } from "@/lib/learning";
import { bi } from "@/lib/lessonsData";
import {
  hashPin,
  initialLearner,
  makeSalt,
  sanitizeLearner,
} from "@/lib/model";
import { Tiger } from "./Art";
import { BiText } from "./UI";

type Step = "welcome" | "kid" | "parent" | "account" | "login" | "reminder";
type AuthResult = {
  ok?: boolean;
  email: string;
  progress?: unknown;
  account?: string;
  error?: string;
};
const signupSteps: Step[] = ["kid", "parent", "account"];

export function AuthFlow({ onDone }: { onDone: () => void }) {
  const { data, update, toast } = useLearning();
  const [step, setStep] = useState<Step>("welcome");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState(
    data.name === "Little Explorer" ? "" : data.name,
  );
  const [age, setAge] = useState(data.age);
  const [pin, setPin] = useState("");
  const [limit, setLimit] = useState(data.limit);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const registering = step === "account";
      if (registering && password !== confirmPassword)
        throw new Error(
          "The two passwords do not match. សូមវាយបញ្ចូលពាក្យសម្ងាត់ដូចគ្នា។",
        );
      let payload: Record<string, unknown>;
      if (registering) {
        const salt = makeSalt();
        const pinHash = await hashPin(pin, salt);
        const progress = sanitizeLearner({
          ...data,
          name: name.trim(),
          age,
          email: email.trim().toLowerCase(),
          account: "live",
          onboarded: true,
          pinHash,
          pinSalt: salt,
          limit,
        });
        payload = { action: "register", email, password, progress };
      } else payload = { action: "login", email, password };
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = (await response.json()) as AuthResult;
      if (!response.ok)
        throw new Error(
          result.error || "Please check your information and try again.",
        );
      const restored = sanitizeLearner(result.progress || initialLearner());
      restored.email = result.email;
      restored.account = "live";
      restored.onboarded = true;
      update(() => restored);
      if (registering) setStep("reminder");
      else {
        toast("Welcome back! Your learning adventure is ready.");
        onDone();
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  }

  async function reminders(ask: boolean) {
    setBusy(true);
    let grant = false;
    try {
      if (ask && typeof Notification !== "undefined")
        grant = (await Notification.requestPermission()) === "granted";
    } catch {
      /* reminders are optional */
    }
    update((s) => ({ ...s, reminder: grant }));
    toast(
      grant
        ? "Daily reminders enabled. Welcome to your adventure!"
        : ask
          ? "Your account is ready. Reminders can be enabled later."
          : "Your account is ready! តោះចាប់ផ្តើមរៀន!",
    );
    setBusy(false);
    onDone();
  }

  const isSignup = signupSteps.includes(step);
  return (
    <div className="auth-flow">
      {step === "welcome" ? (
        <>
          <div className="welcome-art">
            <span>✦</span>
            <Tiger size={102} />
            <i>✧</i>
          </div>
          <span className="eyebrow">WELCOME TO PISETHLEARNING</span>
          <BiText
            text={bi(
              "A little English. A big adventure.",
              "រៀនអង់គ្លេសបន្តិចម្តងៗ ជាមួយដំណើរផ្សងព្រេងដ៏អស្ចារ្យ។",
            )}
            as="h2"
            className="modal-heading"
          />
          <p className="auth-copy">
            A safe, playful learning space for Cambodian families.
          </p>
          <button
            className="primary full two-line-btn"
            onClick={() => {
              setError("");
              setStep("kid");
            }}
          >
            <span>
              Create an account
              <small className="km">
                បង្កើតគណនីថ្មី · សរសេរឈ្មោះ និងអាយុសិស្ស
              </small>
            </span>
            <ArrowRight size={17} />
          </button>
          <button
            className="secondary full"
            onClick={() => {
              setError("");
              setStep("login");
            }}
          >
            Sign in · ចូលប្រើគណនី
          </button>
        </>
      ) : step === "reminder" ? (
        <>
          <div className="onboard-steps">
            {signupSteps.map((s) => (
              <span className="active" key={s} />
            ))}
          </div>
          <div className="modal-icon gold">
            <Bell size={29} />
          </div>
          <span className="eyebrow">ACCOUNT READY · WELCOME!</span>
          <BiText
            text={bi(
              "A friendly daily reminder?",
              "តើចង់ទទួលការរំឭកឱ្យរៀនរាល់ថ្ងៃទេ?",
            )}
            as="h2"
            className="modal-heading"
          />
          <BiText
            text={bi(
              "Your family account is ready. Allow a gentle reminder while the app is open.",
              "គណនីគ្រួសាររួចរាល់ហើយ។ អនុញ្ញាតការរំឭកឱ្យរៀន នៅពេលកម្មវិធីបើក។",
            )}
            className="form-description"
          />
          <button
            className="primary full"
            disabled={busy}
            onClick={() => reminders(true)}
          >
            <Bell size={16} />
            Allow reminders · អនុញ្ញាត
          </button>
          <button
            disabled={busy}
            className="secondary full"
            onClick={() => reminders(false)}
          >
            Not now · ពេលក្រោយ
          </button>
        </>
      ) : (
        <>
          {isSignup && (
            <div className="onboard-steps">
              {signupSteps.map((s, i) => (
                <span
                  key={s}
                  className={signupSteps.indexOf(step) >= i ? "active" : ""}
                />
              ))}
            </div>
          )}
          <div className="modal-icon green">
            {step === "kid" ? (
              <Tiger size={45} />
            ) : step === "parent" ? (
              <ShieldCheck size={29} />
            ) : step === "account" ? (
              <Mail size={28} />
            ) : (
              <KeyRound size={28} />
            )}
          </div>
          {step === "kid" && (
            <>
              <span className="eyebrow">STEP 1 OF 3 · YOUR LEARNER</span>
              <BiText
                as="h2"
                text={bi("Who is learning?", "តើអ្នកណាជាអ្នករៀន?")}
                className="modal-heading"
              />
              <BiText
                text={bi(
                  "Start with the student’s name and age.",
                  "ចាប់ផ្តើមដោយបញ្ចូលឈ្មោះ និងអាយុសិស្ស។",
                )}
                className="form-description"
              />
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setStep("parent");
                  setError("");
                }}
              >
                <label>
                  Student’s name · ឈ្មោះសិស្ស
                  <input
                    autoComplete="given-name"
                    required
                    maxLength={36}
                    placeholder="e.g. Dara"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </label>
                <label>Student’s age · អាយុសិស្ស</label>
                <div className="age-options">
                  {[
                    ["4–6", "៤–៦ ឆ្នាំ"],
                    ["7–10", "៧–១០ ឆ្នាំ"],
                    ["11+", "១១+ ឆ្នាំ"],
                  ].map(([a, k]) => (
                    <button
                      type="button"
                      className={age === a ? "selected" : ""}
                      key={a}
                      onClick={() => setAge(a)}
                    >
                      {a} years<small className="km">{k}</small>
                    </button>
                  ))}
                </div>
                <button className="primary full" disabled={!name.trim()}>
                  Continue · បន្ត <ArrowRight size={16} />
                </button>
              </form>
            </>
          )}
          {step === "parent" && (
            <>
              <span className="eyebrow">STEP 2 OF 3 · GROWN-UPS ONLY</span>
              <BiText
                text={bi(
                  "Set your family’s learning time",
                  "កំណត់ម៉ោងរៀនសម្រាប់គ្រួសារ",
                )}
                as="h2"
                className="modal-heading"
              />
              <BiText
                text={bi(
                  "Choose a private four-digit PIN and your child’s daily limit.",
                  "ជ្រើសរើស PIN សម្ងាត់ ៤ ខ្ទង់ និងម៉ោងរៀនប្រចាំថ្ងៃ។",
                )}
                className="form-description"
              />
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setError("");
                  setStep("account");
                }}
              >
                <label>
                  Parent PIN · លេខសម្ងាត់អាណាព្យាបាល
                  <input
                    className="pin-input"
                    type="password"
                    required
                    pattern="[0-9]{4}"
                    inputMode="numeric"
                    autoComplete="new-password"
                    maxLength={4}
                    placeholder="• • • •"
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                  />
                </label>
                <label>Daily learning limit · ពេលរៀនប្រចាំថ្ងៃ</label>
                <div className="preset-row">
                  {[5, 10, 15, 20, 30].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setLimit(n)}
                      className={limit === n ? "selected" : ""}
                    >
                      {n} min
                    </button>
                  ))}
                </div>
                <button className="primary full" disabled={pin.length !== 4}>
                  Continue · បន្ត <ArrowRight size={16} />
                </button>
              </form>
            </>
          )}
          {step === "account" && (
            <>
              <span className="eyebrow">STEP 3 OF 3 · FAMILY ACCOUNT</span>
              <BiText
                text={bi("Create your sign-in", "បង្កើតព័ត៌មានសម្រាប់ចូលគណនី")}
                as="h2"
                className="modal-heading"
              />
              <BiText
                text={bi(
                  "Use Gmail, Outlook, or another email and a password. No verification code or email is required.",
                  "ប្រើ Gmail, Outlook ឬអ៊ីមែលផ្សេង និងពាក្យសម្ងាត់។ មិនចាំបាច់ផ្ទៀងផ្ទាត់កូដ ឬអ៊ីមែលទេ។",
                )}
                className="form-description"
              />
              <form onSubmit={submit}>
                <label>
                  Family email · អ៊ីមែលគ្រួសារ
                  <input
                    type="email"
                    autoComplete="email"
                    required
                    maxLength={254}
                    placeholder="parent@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </label>
                <label>
                  Password · ពាក្យសម្ងាត់
                  <input
                    type="password"
                    autoComplete="new-password"
                    required
                    minLength={8}
                    maxLength={128}
                    placeholder="At least 8 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </label>
                <label>
                  Confirm password · បញ្ជាក់ពាក្យសម្ងាត់
                  <input
                    type="password"
                    autoComplete="new-password"
                    required
                    minLength={8}
                    maxLength={128}
                    placeholder="Type the password again"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                  />
                </label>
                <p className="muted-caption">
                  Passwords are securely hashed. Keep yours safe; no
                  verification code or automatic password-reset email is used.
                </p>
                {error && (
                  <div className="form-error" role="alert">
                    {error}
                  </div>
                )}
                {error.includes("already uses this email") && (
                  <button
                    type="button"
                    className="text-action account-exists"
                    onClick={() => {
                      setError("");
                      setPassword("");
                      setStep("login");
                    }}
                  >
                    Already have an account? Sign in · មានគណនីហើយ? ចូលគណនី
                  </button>
                )}
                <button
                  className="primary full"
                  disabled={
                    busy ||
                    password.length < 8 ||
                    password !== confirmPassword ||
                    !name.trim()
                  }
                >
                  {busy ? "Creating account…" : "Create account · បង្កើតគណនី"}
                  <Check size={16} />
                </button>
              </form>
              <button
                className="text-action auth-back"
                onClick={() => {
                  setStep("parent");
                  setError("");
                }}
              >
                <ArrowLeft size={13} /> Back to Parent PIN
              </button>
            </>
          )}
          {step === "login" && (
            <>
              <BiText
                text={bi("Welcome back!", "សូមស្វាគមន៍មកវិញ!")}
                as="h2"
                className="modal-heading"
              />
              <BiText
                text={bi(
                  "Sign in with your family email and password.",
                  "ចូលគណនីដោយប្រើអ៊ីមែលគ្រួសារ និងពាក្យសម្ងាត់។",
                )}
                className="form-description"
              />
              <form onSubmit={submit}>
                <label>
                  Family email · អ៊ីមែល
                  <input
                    type="email"
                    autoComplete="username"
                    required
                    maxLength={254}
                    placeholder="parent@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </label>
                <label>
                  Password · ពាក្យសម្ងាត់
                  <input
                    type="password"
                    autoComplete="current-password"
                    required
                    maxLength={128}
                    placeholder="Your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </label>
                <p className="muted-caption">
                  No verification code, email confirmation, or inbox check. Ask
                  your parent for the family password.
                </p>
                {error && (
                  <div className="form-error" role="alert">
                    {error}
                  </div>
                )}
                <button
                  className="primary full"
                  disabled={busy || !email || !password}
                >
                  {busy ? "Signing in…" : "Sign in · ចូលគណនី"}
                  <LockKeyhole size={16} />
                </button>
              </form>
              <button
                className="text-action auth-back"
                onClick={() => {
                  setError("");
                  setPassword("");
                  setStep("welcome");
                }}
              >
                <ArrowLeft size={13} /> Back · ត្រឡប់ក្រោយ
              </button>
            </>
          )}
          {error && isSignup && step !== "account" && (
            <div className="form-error" role="alert">
              {error}
            </div>
          )}
          {isSignup && step !== "account" && (
            <button
              className="text-action auth-back"
              onClick={() => {
                setError("");
                setPassword("");
                setStep(
                  step === "parent"
                    ? "kid"
                    : step === "kid"
                      ? "welcome"
                      : "parent",
                );
              }}
            >
              <ArrowLeft size={13} /> Back · ត្រឡប់ក្រោយ
            </button>
          )}
        </>
      )}
    </div>
  );
}

export function PasswordChange({ onDone }: { onDone: () => void }) {
  const { data, toast } = useLearning();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "change-password",
          email: data.email,
          password: next,
          currentPassword: current,
        }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "Please try again.");
      toast("Your password has been changed.");
      onDone();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <div className="modal-icon green">
        <LockKeyhole size={27} />
      </div>
      <BiText
        as="h2"
        text={bi("Change family password", "ប្តូរពាក្យសម្ងាត់គ្រួសារ")}
        className="modal-heading"
      />
      <BiText
        text={bi(
          "Verify the current password before choosing a new one.",
          "បញ្ជាក់ពាក្យសម្ងាត់ចាស់ មុននឹងកំណត់ពាក្យសម្ងាត់ថ្មី។",
        )}
        className="form-description"
      />
      <form onSubmit={submit}>
        <label>
          Current password
          <input
            type="password"
            autoComplete="current-password"
            required
            maxLength={128}
            value={current}
            onChange={(e) => setCurrent(e.target.value)}
          />
        </label>
        <label>
          New password · At least 8 characters
          <input
            type="password"
            autoComplete="new-password"
            required
            minLength={8}
            maxLength={128}
            value={next}
            onChange={(e) => setNext(e.target.value)}
          />
        </label>
        {error && (
          <div role="alert" className="form-error">
            {error}
          </div>
        )}
        <button
          className="primary full"
          disabled={busy || !current || next.length < 8}
        >
          {busy ? "Saving…" : "Change password · ប្តូរពាក្យសម្ងាត់"}
        </button>
      </form>
    </>
  );
}
