"use client";
import { sound } from "@/lib/audio";
import { useLearning } from "@/lib/learning";
import { bi } from "@/lib/lessonsData";
import {
  bedtimeLocked,
  dayKey,
  formatTime,
  hashPin,
  makeSalt,
  remaining,
} from "@/lib/model";
import {
  Bell,
  Check,
  Clock3,
  KeyRound,
  LockKeyhole,
  Moon,
  Plus,
  ShieldCheck,
  Volume2,
} from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { BiText, Toggle } from "./UI";
export function PinGate({
  onSuccess,
  purpose,
}: {
  onSuccess: () => void;
  purpose: string;
}) {
  const { data } = useLearning();
  const [pin, setPin] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [blocked, setBlocked] = useState(0);
  useEffect(() => {
    const tick = () => {
      try {
        const a = JSON.parse(localStorage.getItem("pl.pin.attempts") || "{}");
        setBlocked(
          Math.max(0, Math.ceil(((a.until || 0) - Date.now()) / 1000)),
        );
      } catch {}
    };
    tick();
    const t = setInterval(tick, 500);
    return () => clearInterval(t);
  }, []);
  async function verify(e: FormEvent) {
    e.preventDefault();
    if (busy || blocked || pin.length !== 4) return;
    setBusy(true);
    setError("");
    try {
      const raw = JSON.parse(localStorage.getItem("pl.pin.attempts") || "{}");
      if (raw.until > Date.now()) {
        setError("Please wait before trying again.");
        return;
      }
      const correct = data.pinHash
        ? (await hashPin(pin, data.pinSalt)) === data.pinHash
        : pin === "0000";
      if (correct) {
        localStorage.removeItem("pl.pin.attempts");
        onSuccess();
      } else {
        const n = (raw.count || 0) + 1;
        localStorage.setItem(
          "pl.pin.attempts",
          JSON.stringify({
            count: n >= 5 ? 0 : n,
            until: n >= 5 ? Date.now() + 30000 : 0,
          }),
        );
        if (n >= 5) setBlocked(30);
        setError("That PIN does not match. Try again.");
        setPin("");
      }
    } catch {
      setError("PIN verification is unavailable. Please use a secure browser.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="pin-view">
      <div className="modal-icon green">
        <ShieldCheck size={33} />
      </div>
      <span className="eyebrow">GROWN-UPS ONLY</span>
      <BiText
        as="h2"
        text={bi("Parent PIN", "លេខសម្ងាត់អាណាព្យាបាល")}
        className="modal-heading"
      />
      <BiText
        text={bi(purpose, "សូមឱ្យអាណាព្យាបាលបញ្ចូលលេខសម្ងាត់ ៤ ខ្ទង់។")}
        className="form-description"
      />
      <form onSubmit={verify}>
        <label htmlFor="parent-pin">
          4-digit Parent PIN <span className="km">លេខសម្ងាត់ ៤ ខ្ទង់</span>
        </label>
        <input
          id="parent-pin"
          type="password"
          autoComplete="current-password"
          inputMode="numeric"
          pattern="[0-9]{4}"
          maxLength={4}
          required
          className="pin-input"
          value={pin}
          onChange={(e) => {
            setPin(e.target.value.replace(/\D/g, ""));
            setError("");
          }}
          placeholder="• • • •"
          autoFocus
        />
        {error && (
          <div role="alert" className="form-error">
            {error}
            <span className="km"> សូមសាកម្តងទៀត។</span>
          </div>
        )}
        <button
          className="primary full"
          disabled={pin.length !== 4 || busy || blocked > 0}
        >
          <LockKeyhole size={16} />
          {blocked
            ? `Try again in ${blocked}s`
            : busy
              ? "Checking…"
              : "Unlock · បើកសោ"}
        </button>
      </form>
      {!data.pinHash && (
        <div className="default-pin">
          <KeyRound size={14} />
          <span>
            First-time parent PIN: <b>0000</b>
            <small>Change it in parental controls.</small>
          </span>
        </div>
      )}
    </div>
  );
}
export function ParentControls({
  onDone,
  onRelock,
}: {
  onDone: () => void;
  onRelock: () => void;
}) {
  const { data, update, toast, seconds } = useLearning();
  const [limit, setLimit] = useState(String(data.limit)),
    [custom, setCustom] = useState(![5, 10, 15, 20, 30].includes(data.limit)),
    [bedOn, setBedOn] = useState(data.bedtimeOn),
    [bed, setBed] = useState(data.bedtime),
    [pin, setPin] = useState(""),
    [name, setName] = useState(data.name),
    [sfx, setSfx] = useState(data.soundOn),
    [reminder, setReminder] = useState(data.reminder),
    [reminderAt, setRAt] = useState(data.reminderAt),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    const t = setTimeout(onRelock, 120000);
    return () => clearTimeout(t);
  }, [onRelock]);
  async function save(e: FormEvent) {
    e.preventDefault();
    const n = Number(limit);
    if (!Number.isInteger(n) || n < 1 || n > 240) {
      setError("Choose a daily limit from 1 to 240 minutes.");
      return;
    }
    if (pin && !/^\d{4}$/.test(pin)) {
      setError("Your new PIN must have exactly 4 digits.");
      return;
    }
    setBusy(true);
    try {
      const salt = pin ? makeSalt() : data.pinSalt;
      const hash = pin ? await hashPin(pin, salt) : data.pinHash;
      update((s) => {
        const value = {
          ...s,
          name: name.trim() || s.name,
          limit: n,
          bedtimeOn: bedOn,
          bedtime: bed,
          pinHash: hash,
          pinSalt: salt,
          soundOn: sfx,
          reminder,
          reminderAt,
          rest: null,
        };
        return {
          ...value,
          rest:
            remaining(value, Date.now()) <= 0
              ? "time"
              : bedtimeLocked(value, new Date())
                ? "bedtime"
                : null,
        };
      });
      toast("Family settings saved · បានរក្សាទុកការកំណត់");
      onDone();
    } catch {
      setError("Could not save the PIN. Use a secure browser and try again.");
    } finally {
      setBusy(false);
    }
  }
  async function allowReminder() {
    if (reminder) {
      setReminder(false);
      return;
    }
    if (typeof Notification === "undefined") {
      setError(
        "This browser does not support notifications. Learning still works normally.",
      );
      return;
    }
    try {
      const p = await Notification.requestPermission();
      setReminder(p === "granted");
      if (p !== "granted")
        setError(
          "Notifications are off. You can allow them in your browser settings.",
        );
    } catch {
      setError("Notifications are not available in this browser.");
    }
  }
  return (
    <>
      <div className="modal-icon green">
        <ShieldCheck size={29} />
      </div>
      <span className="eyebrow">PARENTAL CONTROL PANEL</span>
      <BiText
        as="h2"
        text={bi("Parents’ corner", "កំណត់ម៉ោងរៀនដោយអាណាព្យាបាល")}
        className="modal-heading"
      />
      <div className="parent-time-summary">
        <Clock3 size={18} />
        <span>
          Time left today <span className="km">ពេលនៅសល់</span>
        </span>
        <b>{formatTime(seconds)}</b>
      </div>
      <form className="settings-form" onSubmit={save}>
        <div className="form-group">
          <BiText
            text={bi("Daily learning limit", "រយៈពេលរៀនប្រចាំថ្ងៃ")}
            as="h3"
          />
          <div className="preset-row">
            {[5, 10, 15, 20, 30].map((n) => (
              <button
                type="button"
                key={n}
                className={!custom && Number(limit) === n ? "selected" : ""}
                onClick={() => {
                  setLimit(String(n));
                  setCustom(false);
                }}
              >
                {n} min
              </button>
            ))}
            <button
              type="button"
              className={custom ? "selected" : ""}
              onClick={() => setCustom(true)}
            >
              Custom
            </button>
          </div>
          {custom && (
            <label className="inline-field">
              Minutes · នាទី{" "}
              <input
                type="number"
                min={1}
                max={240}
                step={1}
                required
                value={limit}
                onChange={(e) => setLimit(e.target.value)}
              />
            </label>
          )}
        </div>
        <div className="setting-line">
          <Moon size={19} />
          <div>
            <b>Bedtime lock</b>
            <small className="km">ចាក់សោពេលចូលគេង</small>
          </div>
          <Toggle
            label="Enable bedtime lock"
            checked={bedOn}
            onChange={() => setBedOn(!bedOn)}
          />
        </div>
        {bedOn && (
          <label className="inline-field">
            Lock after · ចាក់សោបន្ទាប់ពី{" "}
            <input
              type="time"
              value={bed}
              onChange={(e) => setBed(e.target.value)}
              required
            />
          </label>
        )}
        <div className="setting-line">
          <Bell size={19} />
          <div>
            <b>Study reminders</b>
            <small className="km">ការរំឭកឱ្យរៀន</small>
          </div>
          <Toggle
            label="Enable daily reminders"
            checked={reminder}
            onChange={allowReminder}
          />
        </div>
        {reminder && (
          <>
            <label className="inline-field">
              Remind at · រំឭកនៅម៉ោង
              <input
                type="time"
                value={reminderAt}
                onChange={(e) => setRAt(e.target.value)}
                required
              />
            </label>
            <p className="muted-caption">
              Daily reminders appear while PisethLearning is open.
            </p>
          </>
        )}
        <div className="setting-line">
          <Volume2 size={19} />
          <div>
            <b>Cheerful sound effects</b>
            <small className="km">សំឡេងលើកទឹកចិត្ត</small>
          </div>
          <Toggle
            label="Learning sound effects"
            checked={sfx}
            onChange={() => setSfx(!sfx)}
          />
        </div>
        <div className="bell-note">
          <span>
            <Bell size={14} />
            The time-up bell stays on.
          </span>
          <button
            type="button"
            className="text-action"
            onClick={() => sound("bell")}
          >
            Test bell
          </button>
        </div>
        <div className="field-grid">
          <label>
            Child’s name<span className="km">ឈ្មោះកុមារ</span>
            <input
              required
              maxLength={36}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </label>
          <label>
            New parent PIN<span className="km">លេខសម្ងាត់ថ្មី</span>
            <input
              type="password"
              inputMode="numeric"
              autoComplete="new-password"
              pattern="[0-9]{4}"
              maxLength={4}
              placeholder="Keep current PIN"
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
            />
          </label>
        </div>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        <button className="primary full" disabled={busy}>
          <Check size={16} />
          {busy ? "Saving…" : "Save settings · រក្សាទុក"}
        </button>
      </form>
      {data.rest && (
        <button
          className="secondary full bonus-time"
          onClick={() => {
            update((s) => ({
              ...s,
              bonus:
                s.bonus +
                Math.max(
                  5,
                  Math.ceil(s.spentMs / 60000) - s.limit - s.bonus + 5,
                ),
              rest: null,
              bedtimePass: dayKey(),
            }));
            toast("Five more minutes approved for today.");
            onDone();
          }}
        >
          <Plus size={16} />
          Allow 5 more minutes today
        </button>
      )}
      <p className="parent-footnote">
        <LockKeyhole size={12} />
        Settings re-lock automatically after two minutes.
      </p>
    </>
  );
}
