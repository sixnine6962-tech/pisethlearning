"use client";
import { primeAudio, sound, speak } from "@/lib/audio";
import { useLearning } from "@/lib/learning";
import {
  bi,
  conversations,
  findLesson,
  units,
  wordBanks,
  type Bilingual,
  type Exercise,
  type Word,
} from "@/lib/lessonsData";
import { formatTime, nextLesson } from "@/lib/model";
import {
  ArrowRight,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Headphones,
  Heart,
  LockKeyhole,
  Mic,
  Moon,
  Repeat2,
  ShieldCheck,
  Sparkles,
  Square,
  Volume2,
  X,
  Zap,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { AppleArt, GemArt, Tiger } from "./Art";
import { AudioButton, BiText, ProgressBar } from "./UI";
type RecognitionResult = {
  results: { [key: number]: { [key: number]: { transcript: string } } };
};
type Recognition = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((e: RecognitionResult) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};
function Speaking({ word, onReady }: { word: Word; onReady: () => void }) {
  const [status, setStatus] = useState<
    "idle" | "listening" | "fallback" | "retry" | "done"
  >("idle");
  const [heard, setHeard] = useState("");
  const rec = useRef<Recognition | null>(null);
  useEffect(
    () => () => {
      if (rec.current) {
        rec.current.onresult = null;
        rec.current.onerror = null;
        rec.current.onend = null;
        rec.current.abort();
      }
    },
    [],
  );
  function record() {
    primeAudio();
    window.speechSynthesis?.cancel();
    const w = window as Window & {
      SpeechRecognition?: new () => Recognition;
      webkitSpeechRecognition?: new () => Recognition;
    };
    const Constructor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Constructor) {
      setStatus("fallback");
      return;
    }
    try {
      const r = new Constructor();
      rec.current = r;
      r.lang = "en-US";
      r.continuous = false;
      r.interimResults = false;
      r.onresult = (e) => {
        const text = e.results[0][0].transcript;
        setHeard(text);
        const norm = (x: string) =>
          x
            .toLowerCase()
            .replace(/[^a-z ]/g, "")
            .trim();
        if (norm(text) === norm(word.en)) {
          setStatus("done");
          onReady();
        } else setStatus("retry");
      };
      r.onerror = () => setStatus("fallback");
      r.onend = () =>
        setStatus((prev) => (prev === "listening" ? "retry" : prev));
      setStatus("listening");
      r.start();
    } catch {
      setStatus("fallback");
    }
  }
  return (
    <div className="speaking-exercise">
      <div className="speak-word-art">{word.icon}</div>
      <BiText as="h2" text={word} />
      <span className="phonetic km">{word.phonetic}</span>
      <div className="audio-pair">
        <AudioButton text={word.en} label="Listen first" />
        <AudioButton text={word.en} slow label="Slow" />
      </div>
      {status === "fallback" ? (
        <div className="offline-practice">
          <BiText
            text={bi(
              "Say the word to your grown-up.",
              "និយាយពាក្យនេះឱ្យអាណាព្យាបាលស្តាប់។",
            )}
          />
          <button
            className="primary"
            onClick={() => {
              setStatus("done");
              onReady();
            }}
          >
            <Check size={16} />I practiced · ខ្ញុំបានហាត់
          </button>
        </div>
      ) : status === "done" ? (
        <span className="success-pill">
          <Check size={16} /> Nicely practiced! · ល្អណាស់!
        </span>
      ) : (
        <>
          <button
            className={`mic-button ${status === "listening" ? "recording" : ""}`}
            onClick={() =>
              status === "listening" ? rec.current?.stop() : record()
            }
          >
            {status === "listening" ? <Square size={25} /> : <Mic size={27} />}
          </button>
          <BiText
            text={
              status === "listening"
                ? bi("Listening… tap to stop", "កំពុងស្តាប់… ចុចដើម្បីឈប់")
                : bi("Tap the microphone and speak", "ចុចមីក្រូហ្វូន រួចនិយាយ")
            }
            className="mic-caption"
          />
          {status === "retry" && (
            <p className="practice-hint">
              {heard ? `I heard “${heard}”. ` : ""}Try once more.{" "}
              <span className="km">សាកម្តងទៀត។</span>
            </p>
          )}
          <button
            className="text-action"
            onClick={() => {
              rec.current?.abort();
              setStatus("fallback");
            }}
          >
            Practice without a microphone · ហាត់ដោយមិនប្រើមីក្រូហ្វូន
          </button>
          <p className="privacy-note">
            Ask a grown-up first. Your browser may process speech online;
            PisethLearning does not save recordings.
          </p>
        </>
      )}
    </div>
  );
}
function Choices({
  choices,
  selected,
  onSelect,
  pictures = false,
  disabled = false,
}: {
  choices: (Bilingual & { icon?: string })[];
  selected: number | null;
  onSelect: (n: number) => void;
  pictures?: boolean;
  disabled?: boolean;
}) {
  return (
    <div className={`answer-choices ${pictures ? "picture-choices" : ""}`}>
      {choices.map((c, i) => (
        <div
          className={`answer-card ${selected === i ? "chosen" : ""}`}
          key={c.en}
        >
          <button
            disabled={disabled}
            className="answer-pick"
            onClick={() => onSelect(i)}
            aria-pressed={selected === i}
          >
            {pictures && <span className="answer-picture">{c.icon}</span>}
            <strong>{c.en}</strong>
            <span className="km" lang="km">
              {c.km}
            </span>
            <span className="choice-number">
              {selected === i ? <Check size={10} /> : i + 1}
            </span>
          </button>
          <AudioButton text={c.en} small />
        </div>
      ))}
    </div>
  );
}
const typeLabels: Record<Exercise["type"], string> = {
  flashcard: "WORD DISCOVERY",
  picture: "PICTURE CHOICE",
  listening: "LISTENING TIME",
  pairs: "MATCHING GAME",
  builder: "SENTENCE BUILDER",
  speaking: "SPEAKING PRACTICE",
  story: "LITTLE CONVERSATION",
};
function ExerciseView({
  q,
  onNext,
  ending,
}: {
  q: Exercise;
  onNext: (speech: boolean) => void;
  ending?: Bilingual;
}) {
  const { data, update } = useLearning();
  const [selected, setSelected] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [tokens, setTokens] = useState<number[]>([]);
  const [left, setLeft] = useState<number | null>(null);
  const [right, setRight] = useState<number | null>(null);
  const [matched, setMatched] = useState<number[]>([]);
  const [pairHint, setPairHint] = useState(false);
  const [revealed, setRevealed] = useState(1);
  const [pronounced, setPronounced] = useState(false);
  const nextLock = useRef(false);
  useEffect(
    () => () => {
      window.speechSynthesis?.cancel();
    },
    [],
  );
  const success = () => {
    setFeedback("correct");
    if (data.soundOn) sound("correct");
  };
  function mismatch() {
    setFeedback("wrong");
    if (data.soundOn) sound("wrong");
    update((s) => ({ ...s, hearts: Math.max(0, s.hearts - 1) }));
  }
  function check() {
    let okay = false;
    if (q.type === "picture" || q.type === "listening")
      okay = selected !== null && q.choices[selected].en === q.word.en;
    else if (q.type === "story") okay = selected === q.answer;
    else if (q.type === "builder")
      okay = tokens.map((i) => q.bank[i]).join(" ") === q.sentence.en;
    else if (q.type === "speaking") okay = pronounced;
    else if (q.type === "pairs") okay = matched.length === 5;
    else okay = true;
    if (okay) success();
    else mismatch();
  }
  function next() {
    if (nextLock.current) return;
    nextLock.current = true;
    onNext(q.type === "speaking");
  }
  function pair(side: "en" | "km", i: number) {
    if (q.type !== "pairs" || matched.includes(i) || feedback === "correct")
      return;
    setPairHint(false);
    if (side === "en") speak(q.words[i].en);
    const a = side === "en" ? i : left,
      b = side === "km" ? i : right;
    setLeft(a);
    setRight(b);
    if (a === null || b === null) return;
    if (a === b) {
      const newMatched = [...matched, a];
      setMatched(newMatched);
      if (newMatched.length === 5) success();
      else if (data.soundOn) sound("correct");
    } else {
      setPairHint(true);
      if (data.soundOn) sound("wrong");
    }
    setLeft(null);
    setRight(null);
  }
  const canCheck =
    q.type === "builder"
      ? tokens.length === q.bank.length
      : q.type === "pairs"
        ? matched.length === 5
        : q.type === "speaking"
          ? pronounced
          : q.type === "flashcard"
            ? true
            : selected !== null;
  return (
    <div className="exercise-view">
      <div className="exercise-eyebrow">
        <Sparkles size={15} />
        {typeLabels[q.type]}
      </div>
      <BiText
        text={
          q.type === "story"
            ? bi("Read the little conversation", "អានការសន្ទនាខ្លីៗ")
            : q.prompt
        }
        as="h1"
        className="exercise-title"
      />
      {q.type === "flashcard" && (
        <div className="flashcard">
          <span className="flash-spark s1">✦</span>
          <span className="flash-spark s2">✧</span>
          {q.word.letter && (
            <span className="flash-letter">
              {q.word.letter}
              <i>{q.word.letter.toLowerCase()}</i>
            </span>
          )}
          <div className="flash-image">
            {q.word.en === "Apple" ? <AppleArt size={103} /> : q.word.icon}
          </div>
          <h2>{q.word.en}</h2>
          <p className="flash-phonetic km">{q.word.phonetic}</p>
          <div className="flash-meaning km" lang="km">
            {q.word.km}
          </div>
          <div className="audio-pair">
            <AudioButton
              text={
                q.word.letter
                  ? `${q.word.letter}. ${q.word.letter} is for ${q.word.en}.`
                  : q.word.en
              }
              label="Listen"
            />
            <AudioButton text={q.word.en} slow label="Slow" />
          </div>
        </div>
      )}
      {(q.type === "picture" || q.type === "listening") && (
        <>
          {q.type === "listening" && (
            <div className="listening-box">
              <Headphones size={34} />
              <div className="waveform" aria-hidden="true">
                {Array.from({ length: 20 }, (_, i) => (
                  <i key={i} style={{ height: 10 + ((i * 17 + 5) % 32) }} />
                ))}
              </div>
              <AudioButton
                text={q.word.en}
                label={q.word.en.includes(" ") ? "Play phrase" : "Play word"}
              />
              <AudioButton text={q.word.en} slow />
            </div>
          )}
          <Choices
            choices={q.choices}
            selected={selected}
            onSelect={(i) => {
              setSelected(i);
              setFeedback(null);
              if (q.type === "picture") speak(q.choices[i].en);
            }}
            pictures={q.type === "picture"}
            disabled={feedback === "correct"}
          />
        </>
      )}
      {q.type === "pairs" && (
        <>
          <div className="pair-columns">
            <div>
              <label>ENGLISH</label>
              {q.words.map((w, i) => (
                <button
                  key={w.en}
                  disabled={matched.includes(i)}
                  className={`${left === i ? "chosen" : ""} ${matched.includes(i) ? "matched" : ""}`}
                  onClick={() => pair("en", i)}
                >
                  {w.en}
                  {matched.includes(i) ? (
                    <Check size={15} />
                  ) : (
                    <Volume2 size={14} />
                  )}
                </button>
              ))}
            </div>
            <div>
              <label>ខ្មែរ · KHMER</label>
              {[2, 4, 0, 3, 1].map((i) => (
                <button
                  key={i}
                  disabled={matched.includes(i)}
                  className={`km ${right === i ? "chosen" : ""} ${matched.includes(i) ? "matched" : ""}`}
                  onClick={() => pair("km", i)}
                >
                  {q.words[i].km}
                  {matched.includes(i) && <Check size={15} />}
                </button>
              ))}
            </div>
          </div>
          <div className="pair-caption" aria-live="polite">
            {pairHint ? (
              <BiText
                text={bi(
                  "Not quite. Try another pair!",
                  "មិនទាន់ត្រូវទេ។ សាកផ្គូផ្គងម្តងទៀត!",
                )}
              />
            ) : (
              <span>
                {matched.length}/5 pairs matched · បានផ្គូផ្គង {matched.length}{" "}
                គូ
              </span>
            )}
          </div>
        </>
      )}
      {q.type === "builder" && (
        <>
          <div className="sentence-target">
            <Tiger size={53} />
            <div>
              <span className="eyebrow">KHMER SENTENCE</span>
              <p className="km" lang="km">
                {q.sentence.km}
              </p>
            </div>
            <AudioButton text={q.sentence.en} />
          </div>
          <div className="build-line" aria-label="Your sentence">
            {tokens.length === 0 ? (
              <BiText
                text={bi("Tap the words below", "ចុចពាក្យខាងក្រោម")}
                className="builder-hint"
              />
            ) : (
              tokens.map((n, i) => (
                <button
                  className="word-token"
                  disabled={feedback === "correct"}
                  key={n}
                  onClick={() => {
                    setTokens((t) => t.filter((_, j) => j !== i));
                    setFeedback(null);
                  }}
                >
                  {q.bank[n]}
                </button>
              ))
            )}
          </div>
          <div className="word-bank">
            {q.bank.map((w, i) => (
              <button
                key={i}
                className="word-token"
                disabled={tokens.includes(i) || feedback === "correct"}
                onClick={() => {
                  setTokens((t) => [...t, i]);
                  speak(w);
                  setFeedback(null);
                }}
              >
                {w}
              </button>
            ))}
          </div>
        </>
      )}
      {q.type === "speaking" && (
        <Speaking
          word={q.word}
          onReady={() => {
            setPronounced(true);
            success();
          }}
        />
      )}
      {q.type === "story" && (
        <>
          <div className="story-lines">
            {q.lines.slice(0, revealed).map((line, i) => (
              <div
                key={i}
                className={`story-line ${line.who === "Mina" ? "mina" : ""}`}
              >
                <span className="story-avatar">
                  {line.who === "Tigo" ? <Tiger size={39} /> : "👧🏻"}
                </span>
                <div className="chat-bubble">
                  <small>{line.who}</small>
                  <BiText text={line} />
                </div>
              </div>
            ))}
          </div>
          {revealed < q.lines.length ? (
            <button
              className="secondary"
              onClick={() => {
                speak(q.lines[revealed].en);
                setRevealed((n) => n + 1);
              }}
            >
              Next line · បន្តអាន <ChevronRight size={15} />
            </button>
          ) : (
            <div className="story-question">
              <BiText text={q.prompt} as="h3" />
              <Choices
                choices={q.choices}
                selected={selected}
                onSelect={(i) => {
                  setSelected(i);
                  setFeedback(null);
                }}
                disabled={feedback === "correct"}
              />
            </div>
          )}
          {feedback === "correct" && ending && (
            <div className="story-ending">
              <CheckCircle2 size={17} />
              <BiText text={ending} />
            </div>
          )}
        </>
      )}
      <div className={`exercise-footer ${feedback || ""}`} aria-live="polite">
        <div>
          {feedback === "correct" ? (
            <BiText
              text={bi("That’s wonderful!", "ល្អណាស់! សូមបន្តទៅមុខ!")}
              as="h3"
            />
          ) : feedback === "wrong" ? (
            <BiText
              text={bi(
                "Almost! Give it another try.",
                "ជិតត្រូវហើយ! សាកម្តងទៀត។",
              )}
              as="h3"
            />
          ) : (
            <div className="lesson-encouragement">
              <LeafMark />
              <BiText text={bi("Take your time.", "រៀនដោយសន្សឹមៗ។")} />
            </div>
          )}
        </div>
        {feedback === "correct" || q.type === "flashcard" ? (
          <button className="primary" onClick={next}>
            {q.type === "flashcard" ? "Got it" : "Continue"}{" "}
            <span className="km">
              {q.type === "flashcard" ? "យល់ហើយ" : "បន្ត"}
            </span>
            <ArrowRight size={16} />
          </button>
        ) : feedback === "wrong" ? (
          <button
            className="secondary"
            onClick={() => {
              setFeedback(null);
              setSelected(null);
              if (q.type === "builder") setTokens([]);
            }}
          >
            Try again <Repeat2 size={15} />
          </button>
        ) : (
          <button className="primary" disabled={!canCheck} onClick={check}>
            Check <span className="km">ពិនិត្យ</span>
            <Check size={16} />
          </button>
        )}
      </div>
    </div>
  );
}
function LeafMark() {
  return <span aria-hidden="true">🌱</span>;
}
export function StudySession({ onExit }: { onExit: () => void }) {
  const { data, seconds, advance, finish, start } = useLearning();
  const sess = data.session!;
  const lesson = findLesson(sess.lessonId)!;
  const unit = units.find((u) => u.lessons.some((l) => l.id === lesson.id))!;
  const c = conversations[sess.activity % conversations.length];
  const questions: Exercise[] =
    sess.mode === "chat"
      ? [
          {
            type: "story",
            id: "chat-" + sess.activity,
            prompt: c.prompt,
            lines: c.lines,
            choices: c.choices,
            answer: c.answer,
          },
        ]
      : sess.mode === "speak"
        ? [
            {
              type: "speaking",
              id: "speak-" + sess.activity,
              prompt: bi("Say it with Tigo", "និយាយជាមួយទីហ្គោ"),
              word: wordBanks[2][sess.activity],
            },
          ]
        : lesson.questions;
  const q = questions[Math.min(sess.index, questions.length - 1)];
  useEffect(() => {
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, []);
  return (
    <div className="study-screen">
      <header className="study-top">
        <button
          className="exit-study"
          onClick={onExit}
          aria-label="End study session with parent PIN"
        >
          <X size={20} />
          <LockKeyhole size={10} />
        </button>
        <div className="study-top-title">
          <b>
            {sess.mode === "lesson"
              ? unit.title.en
              : sess.mode === "chat"
                ? c.title.en
                : "Speaking practice"}
          </b>
          <span className="km">
            {sess.mode === "lesson"
              ? unit.title.km
              : sess.mode === "chat"
                ? c.title.km
                : "ហាត់និយាយ"}
          </span>
        </div>
        <div className="study-stats">
          <span>
            <Heart size={18} fill="#ed858e" stroke="#ed858e" />
            {data.hearts}
          </span>
          <span className="time-pill">
            <Clock3 size={15} />
            {formatTime(seconds)}
          </span>
        </div>
      </header>
      {sess.stage === "complete" ? (
        <div className="complete-wrap">
          <div className="complete-mascot">
            <i>✦</i>
            <Tiger size={118} />
            <b>✧</b>
          </div>
          <span className="eyebrow">A LITTLE WIN WORTH CELEBRATING</span>
          <BiText
            text={bi(
              sess.mode === "lesson"
                ? "Lesson complete!"
                : "Practice complete!",
              "អ្នកធ្វើបានសម្រេចហើយ!",
            )}
            as="h1"
          />
          <div className="complete-stats">
            <div>
              <Zap size={21} />
              <b>{data.xp}</b>
              <span>Total XP</span>
            </div>
            <div>
              <GemArt />
              <b>{data.gems}</b>
              <span>Your gems</span>
            </div>
            <div>
              <BookOpen size={21} />
              <b>{data.completed.length}</b>
              <span>Lessons</span>
            </div>
          </div>
          <button
            className="primary full"
            onClick={() => start(nextLesson(data).id)}
          >
            Next lesson · មេរៀនបន្ទាប់ <ArrowRight size={16} />
          </button>
          <button className="secondary full" onClick={onExit}>
            <LockKeyhole size={15} />
            End session with a grown-up
          </button>
          <p className="km" lang="km">
            សូមឱ្យអាណាព្យាបាលបញ្ចូល PIN ដើម្បីចាកចេញ។
          </p>
        </div>
      ) : (
        <main className="study-main">
          <div className="study-progress">
            <span>
              {sess.mode === "lesson"
                ? `UNIT ${unit.id} · ${lesson.title.en.toUpperCase()}`
                : "YOUR PRACTICE"}
            </span>
            <span>
              {sess.index + 1} / {questions.length}
            </span>
          </div>
          <ProgressBar value={sess.index + 1} max={questions.length} />
          <ExerciseView
            key={q.id}
            q={q}
            ending={
              sess.mode === "chat"
                ? c.ending
                : q.type === "story"
                  ? q.ending
                  : undefined
            }
            onNext={(wasSpeech) => {
              if (sess.index >= questions.length - 1) {
                if (data.soundOn) sound("level");
                finish(wasSpeech);
              } else advance(wasSpeech);
              document
                .querySelector(".study-screen")
                ?.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </main>
      )}
      <div className="study-guardian-note">
        <ShieldCheck size={13} /> Parent-protected learning session{" "}
        <span>·</span> វគ្គរៀនមានការការពារ
      </div>
    </div>
  );
}
export function RestScreen({ onParent }: { onParent: () => void }) {
  const { data } = useLearning();
  return (
    <div className="rest-screen">
      <div className="rest-card">
        <div className="sleepy-scene">
          <Moon size={36} />
          <span className="zz">z Z</span>
          <Tiger size={135} sleeping />
          <i>✦</i>
        </div>
        <span className="eyebrow">REST IS PART OF LEARNING</span>
        <BiText
          as="h1"
          text={
            data.rest === "bedtime"
              ? bi(
                  "Sleepy time, little explorer!",
                  "ដល់ម៉ោងគេងហើយ អ្នករុករកតូច!",
                )
              : bi("Time’s up!", "អស់ម៉ោងរៀនសម្រាប់ថ្ងៃនេះហើយ!")
          }
        />
        <BiText
          text={bi(
            "Rest your eyes, stretch, and play. Tigo will see you tomorrow!",
            "សម្រាកភ្នែក លាតសន្ធឹងខ្លួន ហើយទៅលេង។ ទីហ្គោនឹងជួបអ្នកស្អែក!",
          )}
        />
        <div className="rest-saved">
          <CheckCircle2 size={16} /> Your progress is saved ·
          បានរក្សាទុកការសិក្សា
        </div>
        <button className="secondary" onClick={onParent}>
          <LockKeyhole size={16} />
          Parents’ corner · សម្រាប់អាណាព្យាបាល
        </button>
      </div>
    </div>
  );
}
