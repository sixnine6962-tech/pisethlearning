import type { Learner } from "@/lib/model";
import { sql } from "drizzle-orm";
import {
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const learners = pgTable(
  "piseth_learners",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    subject: text("subject").notNull().unique(),
    email: text("email").notNull(),
    passwordSalt: text("password_salt").notNull().default(""),
    passwordHash: text("password_hash").notNull().default(""),
    progress: jsonb("progress").$type<Learner>(),
    weeklyXp: integer("weekly_xp").notNull().default(0),
    week: text("week").notNull().default(""),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("piseth_password_email_unique")
      .on(t.email)
      .where(sql`${t.passwordSalt} <> ''`),
  ],
);

export const authSessions = pgTable("piseth_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  learnerId: uuid("learner_id")
    .references(() => learners.id, { onDelete: "cascade" })
    .notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

// A short-lived, pseudonymous, PostgreSQL-backed login throttle.
export const authAttemptLimits = pgTable(
  "piseth_auth_attempt_limits",
  {
    bucket: text("bucket").primaryKey(),
    attempts: integer("attempts").notNull().default(0),
    windowStarted: timestamp("window_started", {
      withTimezone: true,
    }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("piseth_auth_rate_expiry").on(t.expiresAt)],
);
