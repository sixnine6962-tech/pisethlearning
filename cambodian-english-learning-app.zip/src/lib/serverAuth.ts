import { db } from "@/db";
import { authSessions, learners } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";
import { cookies } from "next/headers";
import { createHash } from "node:crypto";
import "server-only";
export const digest = (t: string) =>
  createHash("sha256").update(t).digest("hex");
export async function currentLearner() {
  const token = (await cookies()).get("pl_session")?.value;
  if (!token || token.length > 100) return null;
  const [r] = await db
    .select({ learner: learners })
    .from(authSessions)
    .innerJoin(learners, eq(learners.id, authSessions.learnerId))
    .where(
      and(
        eq(authSessions.tokenHash, digest(token)),
        gt(authSessions.expiresAt, new Date()),
      ),
    )
    .limit(1);
  return r?.learner || null;
}
export function safeOrigin(req: Request) {
  const origin = req.headers.get("origin");
  if (!origin) return true;
  try {
    const h = new URL(origin).host;
    return (
      h === req.headers.get("host") || h === req.headers.get("x-forwarded-host")
    );
  } catch {
    return false;
  }
}
export const privateJson = (body: unknown, status = 200) =>
  Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
