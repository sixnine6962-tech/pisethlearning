import { findLesson, units } from "./lessonsData";
export const STORAGE_KEY = "pisethlearning.learner.v1";
export const dayKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export function weekKey(d = new Date()) {
  const x = new Date(d);
  x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
  return dayKey(x);
}
export type Study = {
  lessonId: string;
  index: number;
  clockAt: number;
  stage: "learning" | "complete";
  mode: "lesson" | "chat" | "speak";
  activity: number;
};
export type Learner = {
  version: 1;
  name: string;
  age: string;
  email: string;
  account: "guest" | "demo" | "live";
  onboarded: boolean;
  pinHash: string;
  pinSalt: string;
  limit: number;
  bedtime: string;
  bedtimeOn: boolean;
  reminder: boolean;
  reminderAt: string;
  lastReminder: string;
  soundOn: boolean;
  joinedDay: string;
  day: string;
  spentMs: number;
  bonus: number;
  bedtimePass: string;
  rest: "time" | "bedtime" | null;
  session: Study | null;
  bookmarks: Record<string, number>;
  completed: string[];
  xp: number;
  gems: number;
  hearts: number;
  dates: string[];
  spoken: number;
  daily: { lessons: number; xp: number; speaking: number; claimed: boolean };
  week: string;
  weeklyXp: number;
  inventory: string[];
  avatar: string;
  updatedAt: number;
};
export const initialLearner = (): Learner => ({
  version: 1,
  name: "Little Explorer",
  age: "7–10",
  email: "",
  account: "guest",
  onboarded: false,
  pinHash: "",
  pinSalt: "",
  limit: 15,
  bedtime: "20:30",
  bedtimeOn: false,
  reminder: false,
  reminderAt: "17:00",
  lastReminder: "",
  soundOn: true,
  joinedDay: dayKey(),
  day: dayKey(),
  spentMs: 0,
  bonus: 0,
  bedtimePass: "",
  rest: null,
  session: null,
  bookmarks: {},
  completed: [],
  xp: 0,
  gems: 50,
  hearts: 5,
  dates: [],
  spoken: 0,
  daily: { lessons: 0, xp: 0, speaking: 0, claimed: false },
  week: weekKey(),
  weeklyXp: 0,
  inventory: ["tiger"],
  avatar: "tiger",
  updatedAt: 0,
});
const clamp = (v: unknown, min: number, max: number, fallback: number) =>
  typeof v === "number" && Number.isFinite(v)
    ? Math.min(max, Math.max(min, v))
    : fallback;
const str = (v: unknown, fallback: string, max = 100) =>
  typeof v === "string" ? v.slice(0, max) : fallback;
export function sanitizeLearner(value: unknown): Learner {
  const d = initialLearner();
  if (!value || typeof value !== "object") return d;
  const s = value as Partial<Learner>;
  const strings = (v: unknown, n: number) =>
    Array.isArray(v)
      ? v
          .filter((x): x is string => typeof x === "string" && x.length < 60)
          .slice(0, n)
      : [];
  const result: Learner = {
    ...d,
    name: str(s.name, d.name, 36) || d.name,
    age: ["4–6", "7–10", "11+"].includes(s.age || "") ? s.age! : d.age,
    email: str(s.email, "", 254),
    account: s.account === "demo" || s.account === "live" ? s.account : "guest",
    onboarded: s.onboarded === true,
    pinHash: str(s.pinHash, "", 128),
    pinSalt: str(s.pinSalt, "", 64),
    limit: clamp(s.limit, 1, 240, 15),
    bedtime: /^([01]\d|2[0-3]):[0-5]\d$/.test(s.bedtime || "")
      ? s.bedtime!
      : d.bedtime,
    bedtimeOn: s.bedtimeOn === true,
    reminder: s.reminder === true,
    reminderAt: /^([01]\d|2[0-3]):[0-5]\d$/.test(s.reminderAt || "")
      ? s.reminderAt!
      : d.reminderAt,
    lastReminder: str(s.lastReminder, ""),
    soundOn: s.soundOn !== false,
    joinedDay: /^\d{4}-\d{2}-\d{2}$/.test(s.joinedDay || "")
      ? s.joinedDay!
      : d.joinedDay,
    day: str(s.day, d.day),
    spentMs: clamp(s.spentMs, 0, 86400000, 0),
    bonus: clamp(s.bonus, 0, 240, 0),
    bedtimePass: str(s.bedtimePass, ""),
    rest: s.rest === "time" || s.rest === "bedtime" ? s.rest : null,
    bookmarks: Object.fromEntries(
      Object.entries(s.bookmarks || {})
        .filter(
          ([id, n]) =>
            !!findLesson(id) &&
            Number.isInteger(n) &&
            n >= 0 &&
            n < (findLesson(id)?.questions.length || 0),
        )
        .slice(0, 25),
    ),
    completed: [...new Set(strings(s.completed, 25))].filter(
      (id) => !!findLesson(id),
    ),
    xp: clamp(s.xp, 0, 9999999, 0),
    gems: clamp(s.gems, 0, 99999, 50),
    hearts: clamp(s.hearts, 0, 5, 5),
    dates: [...new Set(strings(s.dates, 730))].filter((x) =>
      /^\d{4}-\d{2}-\d{2}$/.test(x),
    ),
    spoken: clamp(s.spoken, 0, 99999, 0),
    daily: {
      lessons: clamp(s.daily?.lessons, 0, 1000, 0),
      xp: clamp(s.daily?.xp, 0, 99999, 0),
      speaking: clamp(s.daily?.speaking, 0, 1000, 0),
      claimed: s.daily?.claimed === true,
    },
    week: str(s.week, d.week),
    weeklyXp: clamp(s.weeklyXp, 0, 999999, 0),
    inventory: strings(s.inventory, 30).filter((x) =>
      ["tiger", "panda", "fox", "rabbit"].includes(x),
    ),
    avatar: ["tiger", "panda", "fox", "rabbit"].includes(s.avatar || "")
      ? s.avatar!
      : "tiger",
    updatedAt: clamp(s.updatedAt, 0, Date.now() + 10000, 0),
  };
  const sess = s.session;
  if (
    sess &&
    typeof sess === "object" &&
    findLesson(sess.lessonId) &&
    ["lesson", "chat", "speak"].includes(sess.mode)
  ) {
    result.session = {
      ...sess,
      index: Math.floor(
        clamp(
          sess.index,
          0,
          (findLesson(sess.lessonId)?.questions.length || 1) - 1,
          0,
        ),
      ),
      clockAt: clamp(sess.clockAt, 0, Date.now(), Date.now()),
      stage: sess.stage === "complete" ? "complete" : "learning",
      activity: Math.floor(clamp(sess.activity, 0, 2, 0)),
    };
  }
  return rollDay(result);
}
export function rollDay(s: Learner, now = new Date()): Learner {
  let v = s;
  if (s.day !== dayKey(now))
    v = {
      ...v,
      day: dayKey(now),
      spentMs: 0,
      bonus: 0,
      rest: null,
      session: null,
      bedtimePass: "",
      hearts: 5,
      daily: { lessons: 0, xp: 0, speaking: 0, claimed: false },
    };
  if (s.week !== weekKey(now)) v = { ...v, week: weekKey(now), weeklyXp: 0 };
  return v;
}
export const usedMs = (s: Learner, now: number) =>
  s.spentMs + (s.session ? Math.max(0, now - s.session.clockAt) : 0);
export const remaining = (s: Learner, now: number) =>
  Math.max(0, Math.ceil(((s.limit + s.bonus) * 60000 - usedMs(s, now)) / 1000));
export const formatTime = (seconds: number) =>
  `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
export function bedtimeLocked(s: Learner, now: Date) {
  const [h, m] = s.bedtime.split(":").map(Number);
  return (
    s.bedtimeOn &&
    s.bedtimePass !== dayKey(now) &&
    now.getHours() * 60 + now.getMinutes() >= h * 60 + m
  );
}
export const unitUnlocked = (s: Learner, id: number) =>
  id === 1 || units[id - 2].lessons.every((l) => s.completed.includes(l.id));
export function nextLesson(s: Learner) {
  return (
    units.flatMap((u) => u.lessons).find((l) => !s.completed.includes(l.id)) ||
    units[0].lessons[0]
  );
}
export function streak(s: Learner) {
  const d = new Date();
  let count = 0;
  if (!s.dates.includes(dayKey(d))) d.setDate(d.getDate() - 1);
  while (s.dates.includes(dayKey(d))) {
    count++;
    d.setDate(d.getDate() - 1);
  }
  return count;
}
export const makeSalt = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(16)))
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
export async function hashPin(pin: string, salt: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(pin),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: new TextEncoder().encode(salt),
      iterations: 120000,
      hash: "SHA-256",
    },
    key,
    256,
  );
  return Array.from(new Uint8Array(bits))
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
}
