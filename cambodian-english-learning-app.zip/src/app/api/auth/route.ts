import {
  createHmac,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { and, eq, gt, ne, sql } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { authAttemptLimits, authSessions, learners } from "@/db/schema";
import { sanitizeLearner } from "@/lib/model";
import { digest, privateJson, safeOrigin } from "@/lib/serverAuth";

export const dynamic = "force-dynamic";
const KEY_BYTES = 64;
const SCRYPT = { N: 1 << 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
const MAX_ATTEMPTS = 12;
const RATE_WINDOW_MS = 15 * 60_000;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const passwordLength = (value: string) =>
  value.length >= 8 && Buffer.byteLength(value, "utf8") <= 128;

type Account = typeof learners.$inferSelect;

async function passwordDigest(password: string, salt: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCallback(password, salt, KEY_BYTES, SCRYPT, (error, result) => {
      if (error) reject(error);
      else resolve(result);
    });
  });
}

function normalizeEmail(value: unknown) {
  return typeof value === "string" ? value.trim().toLowerCase() : "";
}

async function chargeRateLimit(req: Request, email: string) {
  const forwarded =
    req.headers.get("x-real-ip") ||
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    "shared";
  const pepper = process.env.AUTH_RATE_LIMIT_SECRET || process.env.DATABASE_URL;
  const bucket = createHmac("sha256", pepper || "piseth-auth-rate-limit")
    .update(`${forwarded.slice(0, 100)}\0${email}`)
    .digest("hex");
  const now = new Date();
  const cutoff = new Date(now.getTime() - RATE_WINDOW_MS);
  const nextExpiry = new Date(now.getTime() + RATE_WINDOW_MS);
  const [row] = await db
    .insert(authAttemptLimits)
    .values({ bucket, attempts: 1, windowStarted: now, expiresAt: nextExpiry })
    .onConflictDoUpdate({
      target: authAttemptLimits.bucket,
      set: {
        attempts: sql`case when ${authAttemptLimits.windowStarted} <= ${cutoff} then 1 else ${authAttemptLimits.attempts} + 1 end`,
        windowStarted: sql`case when ${authAttemptLimits.windowStarted} <= ${cutoff} then ${now} else ${authAttemptLimits.windowStarted} end`,
        expiresAt: sql`case when ${authAttemptLimits.windowStarted} <= ${cutoff} then ${nextExpiry} else ${authAttemptLimits.expiresAt} end`,
      },
    })
    .returning({ attempts: authAttemptLimits.attempts });
  if (Math.random() < 0.02)
    await db
      .delete(authAttemptLimits)
      .where(sql`${authAttemptLimits.expiresAt} < ${now}`);
  return {
    bucket,
    allowed: (row?.attempts ?? MAX_ATTEMPTS + 1) <= MAX_ATTEMPTS,
  };
}

async function clearRateLimit(bucket: string) {
  await db
    .delete(authAttemptLimits)
    .where(eq(authAttemptLimits.bucket, bucket));
}

async function issueSession(req: Request, account: Account, progress: unknown) {
  const jar = await cookies();
  const previous = jar.get("pl_session")?.value;
  const token = randomBytes(32).toString("hex");
  await db.transaction(async (tx) => {
    if (previous && /^[a-f0-9]{64}$/i.test(previous)) {
      await tx
        .delete(authSessions)
        .where(eq(authSessions.tokenHash, digest(previous)));
    }
    await tx.insert(authSessions).values({
      tokenHash: digest(token),
      learnerId: account.id,
      expiresAt: new Date(Date.now() + 30 * 86_400_000),
    });
  });
  jar.set("pl_session", token, {
    httpOnly: true,
    sameSite: "strict",
    path: "/",
    secure:
      req.headers.get("x-forwarded-proto") === "https" ||
      new URL(req.url).protocol === "https:",
    maxAge: 30 * 86_400,
  });
  return privateJson({
    ok: true,
    account: "live",
    email: account.email,
    progress,
  });
}

async function matchesPassword(account: Account | undefined, password: string) {
  const valid =
    !!account &&
    /^[a-f0-9]{32}$/i.test(account.passwordSalt) &&
    /^[a-f0-9]{128}$/i.test(account.passwordHash);
  const salt = valid ? account.passwordSalt : randomBytes(16).toString("hex");
  const candidate = await passwordDigest(password, salt);
  const stored = Buffer.from(
    valid ? account.passwordHash : randomBytes(KEY_BYTES).toString("hex"),
    "hex",
  );
  return timingSafeEqual(candidate, stored) && valid;
}

export async function POST(req: Request) {
  if (!safeOrigin(req))
    return privateJson({ error: "Request origin is not allowed." }, 403);
  try {
    const raw = await req.text();
    if (raw.length > 48_000)
      return privateJson({ error: "The request is too large." }, 413);
    let value: unknown;
    try {
      value = JSON.parse(raw);
    } catch {
      return privateJson(
        { error: "Please check the information and try again." },
        400,
      );
    }
    if (!value || typeof value !== "object" || Array.isArray(value))
      return privateJson({ error: "Invalid request." }, 400);
    const body = value as Record<string, unknown>;

    if (body.action === "logout") {
      const jar = await cookies();
      const token = jar.get("pl_session")?.value;
      if (token && /^[a-f0-9]{64}$/i.test(token))
        await db
          .delete(authSessions)
          .where(eq(authSessions.tokenHash, digest(token)));
      jar.delete("pl_session");
      return privateJson({ ok: true });
    }

    const action = body.action;
    if (
      action !== "register" &&
      action !== "login" &&
      action !== "change-password"
    ) {
      return privateJson(
        { error: "Choose “Create an account” or “Sign in.”" },
        400,
      );
    }
    const email = normalizeEmail(body.email);
    if (email.length > 254 || !EMAIL_PATTERN.test(email)) {
      return privateJson(
        {
          error: "Please enter a valid Gmail, Outlook, or other email address.",
        },
        400,
      );
    }

    if (action === "register") {
      const password = typeof body.password === "string" ? body.password : "";
      if (!passwordLength(password))
        return privateJson(
          {
            error:
              "Use a password with at least 8 characters (maximum 128 bytes).",
          },
          400,
        );
      const source =
        body.progress &&
        typeof body.progress === "object" &&
        !Array.isArray(body.progress)
          ? (body.progress as Record<string, unknown>)
          : null;
      if (
        !source ||
        source.onboarded !== true ||
        typeof source.name !== "string" ||
        !source.name.trim() ||
        !["4–6", "7–10", "11+"].includes(String(source.age)) ||
        !/^[a-f0-9]{64}$/i.test(String(source.pinHash || "")) ||
        !/^[a-f0-9]{32}$/i.test(String(source.pinSalt || ""))
      ) {
        return privateJson(
          { error: "Please finish the student and parent setup first." },
          400,
        );
      }
      const rate = await chargeRateLimit(req, email);
      if (!rate.allowed)
        return privateJson(
          {
            error:
              "Too many attempts. Please wait 15 minutes before trying again.",
          },
          429,
        );
      const progress = sanitizeLearner(source);
      progress.email = email;
      progress.account = "live";
      progress.onboarded = true;
      progress.updatedAt = Date.now();
      const salt = randomBytes(16).toString("hex");
      const passwordHash = (await passwordDigest(password, salt)).toString(
        "hex",
      );
      try {
        const [created] = await db
          .insert(learners)
          .values({
            subject: `password:${email}`,
            email,
            passwordSalt: salt,
            passwordHash,
            progress,
            weeklyXp: progress.weeklyXp,
            week: progress.week,
          })
          .returning();
        await clearRateLimit(rate.bucket);
        return await issueSession(req, created, created.progress);
      } catch (cause) {
        if (
          cause &&
          typeof cause === "object" &&
          "code" in cause &&
          (cause as { code?: string }).code === "23505"
        ) {
          return privateJson(
            {
              error:
                "An account already uses this email. Choose “Sign in” instead.",
            },
            409,
          );
        }
        throw cause;
      }
    }

    if (action === "login") {
      const rate = await chargeRateLimit(req, email);
      if (!rate.allowed)
        return privateJson(
          {
            error:
              "Too many attempts. Please wait 15 minutes before trying again.",
          },
          429,
        );
      const password =
        typeof body.password === "string" &&
        Buffer.byteLength(body.password, "utf8") <= 128
          ? body.password
          : "";
      const [account] = await db
        .select()
        .from(learners)
        .where(and(eq(learners.email, email), ne(learners.passwordSalt, "")))
        .limit(1);
      if (!password || !(await matchesPassword(account, password)))
        return privateJson({ error: "Email or password is incorrect." }, 401);
      await clearRateLimit(rate.bucket);
      const progress = sanitizeLearner(account?.progress);
      progress.email = email;
      progress.account = "live";
      progress.onboarded = true;
      return await issueSession(req, account, progress);
    }

    const token = (await cookies()).get("pl_session")?.value;
    const [session] =
      token && /^[a-f0-9]{64}$/i.test(token)
        ? await db
            .select({ learnerId: authSessions.learnerId })
            .from(authSessions)
            .where(
              and(
                eq(authSessions.tokenHash, digest(token)),
                gt(authSessions.expiresAt, new Date()),
              ),
            )
            .limit(1)
        : [];
    if (!session)
      return privateJson(
        { error: "Please sign in again before changing your password." },
        401,
      );
    const [account] = await db
      .select()
      .from(learners)
      .where(and(eq(learners.id, session.learnerId), eq(learners.email, email)))
      .limit(1);
    if (!account)
      return privateJson(
        { error: "This family account could not be found." },
        401,
      );
    const rate = await chargeRateLimit(req, email);
    if (!rate.allowed)
      return privateJson(
        {
          error:
            "Too many attempts. Please wait 15 minutes before trying again.",
        },
        429,
      );
    const current =
      typeof body.currentPassword === "string" &&
      Buffer.byteLength(body.currentPassword, "utf8") <= 128
        ? body.currentPassword
        : "";
    const newPassword = typeof body.password === "string" ? body.password : "";
    if (!current || !passwordLength(newPassword))
      return privateJson(
        {
          error:
            "Enter your current password and choose a new password with at least 8 characters.",
        },
        400,
      );
    if (!(await matchesPassword(account, current)))
      return privateJson({ error: "The current password is incorrect." }, 401);
    const salt = randomBytes(16).toString("hex");
    const passwordHash = (await passwordDigest(newPassword, salt)).toString(
      "hex",
    );
    const nextToken = randomBytes(32).toString("hex");
    await db.transaction(async (tx) => {
      await tx
        .update(learners)
        .set({ passwordSalt: salt, passwordHash, updatedAt: new Date() })
        .where(eq(learners.id, account.id));
      await tx
        .delete(authSessions)
        .where(eq(authSessions.learnerId, account.id));
      await tx
        .insert(authSessions)
        .values({
          tokenHash: digest(nextToken),
          learnerId: account.id,
          expiresAt: new Date(Date.now() + 30 * 86_400_000),
        });
    });
    const jar = await cookies();
    jar.set("pl_session", nextToken, {
      httpOnly: true,
      sameSite: "strict",
      path: "/",
      secure:
        req.headers.get("x-forwarded-proto") === "https" ||
        new URL(req.url).protocol === "https:",
      maxAge: 30 * 86_400,
    });
    await clearRateLimit(rate.bucket);
    return privateJson({ ok: true, email });
  } catch {
    return privateJson(
      {
        error:
          "Sign-in is temporarily unavailable. Please try again. Your learning progress is safe.",
      },
      503,
    );
  }
}
