import "@fontsource-variable/kantumruy-pro";
import "@fontsource-variable/nunito-sans";
import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = {
  title: "PisethLearning — English for little explorers",
  description:
    "A playful bilingual English classroom for Cambodian children. Learn with Tigo through illustrated lessons, stories, and parent-protected practice.",
  applicationName: "PisethLearning",
  authors: [{ name: "TryPiseth.LLC" }],
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#f7f9fa",
};
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
