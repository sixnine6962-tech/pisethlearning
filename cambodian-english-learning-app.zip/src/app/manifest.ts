import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "PisethLearning — English for little explorers",
    short_name: "PisethLearning",
    description: "Bilingual English adventures for Cambodian children.",
    start_url: "/",
    display: "standalone",
    background_color: "#f7f8fa",
    theme_color: "#248765",
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" },
    ],
  };
}
